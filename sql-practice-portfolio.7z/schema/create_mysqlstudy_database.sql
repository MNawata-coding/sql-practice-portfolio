--データベース作成
CREATE DATABASE mysqlstudy;
