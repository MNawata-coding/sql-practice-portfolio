DELETE FROM items;

