--usersテーブル全削除
DELETE FROM users;

--usersテーブルで特定のレコードを削除
DELETE FROM users WHERE name='七上テスト'

