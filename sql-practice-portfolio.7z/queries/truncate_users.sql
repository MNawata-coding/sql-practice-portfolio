--usersテーブル内のデータを削除
TRUNCATE TABLE users;