INSERT INTO users (name, email, role, created_by, updated_at, delete_flg) 
values ('taro', 'example@example.com', 'USER', 'SYSTEM', NULL, false);

--演習用
INSERT INTO users (name) VALUES ('Taro');
INSERT INTO users (name) VALUES ('Hanako');
INSERT INTO users (name) VALUES ('Jiro');
INSERT INTO users (name) VALUES ('Miki');