--usersテーブルをアップデート
UPDATE users SET name='jiro', email='jiro@example.com';

--usersテーブルで特定の値をアップデート
UPDATE users SET name='七上テスト' WHERE name='七上隆太'